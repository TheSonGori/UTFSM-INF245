INTEGRANTES
    Nombre: Alan Ojeda Rodriguez | Rol: 202173524-0 | Paralelo: 201
    Nombre: Javiera Gutierrez Abarca | Rol: 202173626-3 | Paralelo: 200

INTRUCCIONES DE USO / EJECUCION DEL PROGRAMA
    Se asume que :
        - El archivo "numeros.txt" siempre las letras estaran en mayusculas.
        - Tambien que la ñ y letras con tildes jamas apareceran en el .txt.
        - El usuario siempre ingresa un valor int(). Por ejemplo:
            * "Ingrese un numero: 12 " -> Correcto
            * "Ingrese un numero: AB " -> Incorrecto

    Funciones formato comentario:
        '''
        Explicacion breve de que es lo que hace la funcion
            Parametros: # Parametros funcion
                parametro1:

            Returns: # Retornos 
                tipo: 
        '''
    
     