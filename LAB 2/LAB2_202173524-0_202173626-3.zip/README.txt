INTEGRANTES
    Nombre: Alan Ojeda Rodriguez     | Rol: 202173524-0 | Paralelo: 201
    Nombre: Javiera Gutierrez Abarca | Rol: 202173626-3 | Paralelo: 200

INTRUCCIONES DE USO / EJECUCION DEL PROGRAMA
    
     -> Para hacer que el programa cicle estando el clock activado, manualmente hay que cambiar el valor de MUX en main
	de 0 a 1 cuando las flechas dejen de estar en rojo. (Main: Logica de estado -> Mux). Con esto el programa llegara
	a la salida.
	
	-> Lo anterior, es debido a que por mas que intentamos replicar el flip flop tipo D que esta en la libreria memoria
	para que en un ciclo tenga un 0 y luego sea siempre 1 (como lo hace el de la libreria). No hubo forma, ya que con las
	librerias que estan disponibles se bloquean muchos caminos que se podrian tomar. 
	