INTEGRANTES
    Nombre: Alan Ojeda Rodriguez     | Rol: 202173524-0 | Paralelo: 201
    Nombre: Javiera Gutierrez Abarca | Rol: 202173626-3 | Paralelo: 200

INTRUCCIONES DE USO / EJECUCION DEL PROGRAMA
	ROM:
	-> El ROM[0] hasta el ROM[7] son los ejemplos de prueba entregados en el .pdf. del ROM[8] en adelante son datos rellenos que
	usamos para completar de llenar la ROM (todo esto escrito en el design.sv).
	-> Con lo anterior para cambiar estos valores a los de prueba debe ser desde el archivo design.sv.
	-> En el el ejemplo del .pdf en nuestro caso el ROM[7] sale "ignorado" en el Inmediato B y para que de el resultado esperado,
	se toma el inmediato B del ejemplo anterior, ROM[6].

	PREFIXADDER:
	-> Nuestro PrefixAdder esta inspirado del que sale en el texto guia. Este fue modificado para que lograra hacer sumas y restas
	correctamente.
    	-> En otras palabras hacemos uso de "always_comb"