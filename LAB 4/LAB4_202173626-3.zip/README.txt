Integrantes:
	Nombre: Javiera Gutierrez Abarca	Rol: 202173626-3		Paralelo: 200

	* Mi compañero congelo y no logre encontrar a alguien. Igualmente, le pregunte al profesor Viktor si podia 
	ser sola y me dijo que no habia problema.

Ejecución:
	-> Para elegir una operacion en la line 21 se encuentra un "operacion: .word [x]", donde x puede ser:

		x = 1 - Verificar Anagrama
		x = 2 - Funcion Recursiva
		x = 3 - Multiplos de 2

	   *IMPORTANTE: Se asume que este valor [X] lo ingresa el usuario antes de iniciar el programa *

	-> [x=1] line 41 - anagrama:
		Para cambiar los valores de esta funcion:
			-> Line 5: string1: .asciz ["str1"]
			-> Line 6: string2: .asciz ["str2"]

	-> [x=3] line 132 - recursiva:
		Para cambiar los valores de esta funcion:
			-> Line 9: n: .word [n]
			-> Line 10: k: .word [k]

	-> [x=3] line 194 - multiplos:
		Para cambiar los valores de esta funcion:
			-> Line 13: dimension: .word [d]
			-> Line 14: vector: .word [array]
		Para la creacion de esta funcion me base del codigo entregado de la 'Ayudantia 8 - Pregunta 2', 
		modificandolo para que ahora pudiera imprimir los valores que son pares.
	